package com.farmmarketplace.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
